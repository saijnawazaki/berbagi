<?php
defined('APP_PATH') OR exit('No direct script access allowed');

require 'function.php';
require 'engine.php';
require 'view.php';