<?php
define('APP_TITLE', 'Berbagi');
define('APP_VERSION', '1.2');